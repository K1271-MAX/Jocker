function getQueryParams() {
  return new URLSearchParams(window.location.search);
}

function displayButtonPressed() {
  const params = getQueryParams();
  const buttonId = params.get('buttonId');
  switch (buttonId){
    case '0': {
      document.title = "老蒋快跑";
      //document.getElementById('Game_ID').textContent = `../page/game.html`;
      const iframe = document.getElementById('Game_ID');
      iframe.src = "../game/老蒋快跑.html";
      break;
    }
    case "1": {

      break;
    }
  }
}
window.onload = displayButtonPressed;
