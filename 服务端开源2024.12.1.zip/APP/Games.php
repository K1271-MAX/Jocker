<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>游戏</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed; 
            top: 0; 
            width: 100%; 
            z-index: 1000; 
        }
        header p {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .container{
            position: relative;
            top: 10px; 
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007BFF;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .button:active {
            background-color: #004080;
        }
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed;
            bottom: 0;
            width: 100%;
            display: flex;
            justify-content: space-between; 
            align-items: center; 
        }
        .footer a {
            color: white;
            text-decoration: none;
            padding: 0 10px;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        .footer a.check {
            background-color: #ff00aa; 
            border-radius: 10px 10px 10px 10px;
            padding: 5px 10px; 
        }
        .footer a.uncheck{
            border-radius: 10px 10px 10px 10px;
            background-color: #000000; 
            padding: 5px 10px; 
        }
        .footer a.check:hover {
            background-color: #ff00aa; 
        }
        .footer a.uncheck:hover {
            background-color: #ff00aa; 
        }
        p {
            margin-bottom: 0px; /* 设置段落底部的外边距 */
        }
    </style>
</head>
<body>
    <header>
        <p>游戏</p>
    </header>

    <div>
        <h2 class="container">游戏列表：</h2>
    </div>
    <a href="老蒋恋爱日记_In.html" class="button">1.老蒋恋爱日记V1.0.B (开发中) </a>
    <div class="footer">
        <a href="Main.php" class="uncheck">资讯</a>
        <a href="Games.php" class="check">游戏</a>
        <a href="About.php" class="uncheck">用户</a>
    </div>
</body>
</html>