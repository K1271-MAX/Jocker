<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>资讯</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed; 
            top: 0; 
            width: 100%; 
            z-index: 1000; 
        }
        header p {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .container{
            position: relative;
            top: 10px; 
        }
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed;
            bottom: 0;
            width: 100%;
            display: flex;
            justify-content: space-between; 
            align-items: center; 
        }
        .footer a {
            color: white;
            text-decoration: none;
            padding: 0 10px;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        .footer a.check {
            background-color: #ff00aa; 
            border-radius: 10px 10px 10px 10px;
            padding: 5px 10px; 
        }
        .footer a.uncheck{
            border-radius: 10px 10px 10px 10px;
            background-color: #000000; 
            padding: 5px 10px; 
        }
        .footer a.check:hover {
            background-color: #ff00aa; 
        }
        .footer a.uncheck:hover {
            background-color: #ff00aa; 
        }
        p {
            margin-bottom: 0px; /* 设置段落底部的外边距 */
        }
    </style>
<script>
function startTime(){
	var today=new Date();
	var h=today.getHours();
	var m=today.getMinutes();
	var s=today.getSeconds();// 在小于10的数字前加一个‘0’
	m=checkTime(m);
	s=checkTime(s);
	document.getElementById('txt').innerHTML="服务器时间:"+h+":"+m+":"+s;
	t=setTimeout(function(){startTime()},500);
}
function checkTime(i){
	if (i<10){
		i="0" + i;
	}
	return i;
}
</script>
</head>
<body onload="startTime()">
    <header>
        <p>资讯</p>
    </header>
    <div>
        <h4 class="container">[广告] 此广告位招商！</h4>
    </div>
    <div>
     <p id="txt"></p>
    </div>
    <div class="footer">
        <a href="Main.php" class="check">资讯</a>
        <a href="Games.php" class="uncheck">游戏</a>
        <a href="About.php" class="uncheck">用户</a>
    </div>
</body>
</html>