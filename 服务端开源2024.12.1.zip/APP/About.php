<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>关于</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed; 
            top: 0; 
            width: 100%; 
            z-index: 1000; 
        }
        header p {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .container{
            position: relative;
            top: 10px; 
        }
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0px;
            position: fixed;
            bottom: 0;
            width: 100%;
            display: flex;
            justify-content: space-between; 
            align-items: center; 
        }
        .footer a {
            color: white;
            text-decoration: none;
            padding: 0 10px;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        .footer a.check {
            background-color: #ff00aa; 
            border-radius: 10px 10px 10px 10px;
            padding: 5px 10px; 
        }
        .footer a.uncheck{
            border-radius: 10px 10px 10px 10px;
            background-color: #000000; 
            padding: 5px 10px; 
        }
        .footer a.check:hover {
            background-color: #ff00aa; 
        }
        .footer a.uncheck:hover {
            background-color: #ff00aa; 
        }
        p {
            margin-bottom: 0px; 
        }
    </style>
</head>
<body>
    <header>
        <p>关于</p>
    </header>

    <div>
        <h2 class="container">欢迎来到关于页面</h2>
    </div>

    <div class="footer">
        <a href="Main.php" class="uncheck">资讯</a>
        <a href="Games.php" class="uncheck">游戏</a>
        <a href="#Users.php" class="check">用户</a>
    </div>
</body>
</html>